<?php

function post_install() {

    require_once 'modules/Configurator/Configurator.php';
    $configuratorObj = new Configurator();
    //Load config
    $configuratorObj->loadConfig();
    //Update a specific setting
    $configuratorObj->config['oauth2']['max_session_lifetime'] = "21600";
    $configuratorObj->config['oauth2']['access_token_lifetime'] = "21600";
    //Save the new setting
    $configuratorObj->saveConfig();

    // QRR
    taskRunFullQRR();
}

/**
 * Runs full quick repair and rebuild.
 */
function taskRunFullQRR() {
    global $mod_strings;
    global $current_user;

    // we don't have such situations, just adding it for the future just in case
    unset($GLOBALS['installing']);

    // force developer mode for full vardef/dictionary refresh
    $backupDevMode = inDeveloperMode();
    $sugar_config['developerMode'] = true;

    // setup LBL_ALL_MODULES for full QRR
    $backupModStrings = isset($mod_strings) ? $mod_strings : null;
    require 'modules/Administration/language/en_us.lang.php';

    // rebuilding sugar logic 
    if (is_admin($current_user)) {
        require_once("include/Expressions/updatecache.php");
    }
    // perform full QRR - execute query mode
    require_once 'modules/Administration/QuickRepairAndRebuild.php';
    $repairer = new RepairAndClear();
    $repairer->repairAndClearAll(array('clearAll'), array($mod_strings['LBL_ALL_MODULES']), true, false);

    // reset altered flags to it's original state
    $GLOBALS['installing'] = true;
    $sugar_config['developerMode'] = $backupDevMode;
    $mod_strings = $backupModStrings;
}
