<?php
    $manifest = array (
        'acceptable_sugar_versions' => 
        array (
            'regex_matches'=>array('7.*', '8.*'),
        ),
        'acceptable_sugar_flavors' => array(
            'PRO','CORP','ENT','ULT','CE'
        ),
        'key'=>'',
        'author' => 'Rolustech',
        'description' => 'Increase Login Session Time',
        'icon' => '',
        'is_uninstallable' => true,
        'name' => 'Increase Login Session Time',
        'published_date' => '2018-10-11 18:00:00',
        'type' => 'module',
        'version' => '1.0',
        'remove_tables' => 'prompt',
    );
    $installdefs = array (
        'id' => 'IncreaseLoginSessionTime',
        'post_install' => array(
            '<basepath>/scripts/post_install.php',
        ),
        'pre_uninstall' => array(
            '<basepath>/scripts/pre_uninstall.php',
        ),
    );
